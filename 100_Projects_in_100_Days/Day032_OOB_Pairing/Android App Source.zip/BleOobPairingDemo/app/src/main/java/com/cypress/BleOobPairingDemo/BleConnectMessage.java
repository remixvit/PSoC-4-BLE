package com.cypress.BleOobPairingDemo;

import java.util.Arrays;

/**
 * Created by vair on 12/3/2015.
 */
public class BleConnectMessage {

    public static final int ADDRESS_DATA_TYPE = 0x1B;
    public static final int LE_ROLE_DATA_TYPE = 0x1C;
    public static final int APPEARANCE_DATA_TYPE = 0x19;
    public static final int LOCAL_NAME_DATA_TYPE = 0x09;
    public static final int SECURITY_KEY_DATA_TYPE = 0x10;
    public static final int SECURITY_KEY_SIZE = 16;
    public static final int ADDRESS_SIZE = 7;

    private byte[] payload;
    private byte[] address;
    private String localName;
    private byte[] securityKey;

    public BleConnectMessage(byte[] payload){
        this.payload = payload;
        parsePayload();
    }

    public byte[] getAddress(){
        return address;
    }

    public byte[] getSecurityKey(){
        return securityKey;
    }

    public String getLocalName(){
        return localName;
    }

    private void parsePayload(){
        for(int i = 0; i < payload.length;){
            int length = payload[i++] - 1; /* Length includes 1 byte data type */
            int dataType = payload[i++];
            switch(dataType){
                case ADDRESS_DATA_TYPE:
                    if(length == ADDRESS_SIZE) {
                        address = Arrays.copyOfRange(payload, i, i + length);
                    }
                    break;

                case LE_ROLE_DATA_TYPE:
                    break;

                case APPEARANCE_DATA_TYPE:
                    break;

                case LOCAL_NAME_DATA_TYPE:
                    localName = new String(Arrays.copyOfRange(payload, i, i + length));
                    break;

                case SECURITY_KEY_DATA_TYPE:
                    if(length == SECURITY_KEY_SIZE) {
                        securityKey = Arrays.copyOfRange(payload, i, i + length);
                    }
            }
            i += length;
        }
    }
}
