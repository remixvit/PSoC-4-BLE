package com.cypress.BleOobPairingDemo;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.Parcelable;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import com.hoho.android.usbserial.driver.CdcAcmSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.util.HexDump;
import com.hoho.android.usbserial.util.SerialInputOutputManager;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends ActionBarActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int COLOR_RED = 0xFFFF0000;
    private static final String SENDER_APP ="APP:  ";
    private static final String SENDER_PSoC = "";
    private static final int VID = 0x04B4;
    private static final int PID = 0xF139;
    private static final int BAUD_RATE = 115200;
    private static final int CTRL_IFACE_NUM = 2;
    private static final int DATA_IFACE_NUM = 3;

    Tag nfcTag;
    IntentFilter[] nfcIntentFiltersArr;
    PendingIntent nfcPendingIntent;
    private TextView consoleText;
    private ScrollView scrollBar;
    private SerialInputOutputManager serialIoManager;
    private UsbSerialPort sPort = null;
    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();
    private boolean isTagConfigureMode = false;

    private final BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
               closeUsbConnection();
                updateConsole(SENDER_APP, "USB device disconnected.\r\n");
            }
        }
    };

    private final SerialInputOutputManager.Listener mListener =
            new SerialInputOutputManager.Listener() {

                @Override
                public void onRunError(Exception e) {
                    Log.d(TAG, "Runner stopped.");
                }

                @Override
                public void onNewData(final byte[] data) {
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            MainActivity.this.updateConsole(SENDER_PSoC, data);
                        }
                    });
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* If the phone doesn't have NFC ask user for termination */
        NfcAdapter adapter = NfcAdapter.getDefaultAdapter(this);
        if (adapter == null) {
            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which){
                        case DialogInterface.BUTTON_POSITIVE:
                            MainActivity.this.finish();
                            break;
                    }
                }
            };

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Oops. This phone doesn't have NFC. Terminate App?").setPositiveButton("Yes", dialogClickListener)
                    .setNegativeButton("No", dialogClickListener).show();
        }

        consoleText = (TextView)findViewById(R.id.consoleText);
        scrollBar = (ScrollView)findViewById(R.id.scrollView);
        updateConsole(SENDER_APP, "Connect the PSoC BLE kit and Scan a tag to continue. \r\n");
        registerReceiver(mUsbReceiver, new IntentFilter(UsbManager.ACTION_USB_DEVICE_DETACHED));

        if(adapter != null) {
        /* Foreground dispatcher for NFC */
            nfcPendingIntent = PendingIntent.getActivity(
                    this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);

            IntentFilter ndefDiscoveredFilter = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
            IntentFilter tagDiscoveredFilter = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
            nfcIntentFiltersArr = new IntentFilter[]{ndefDiscoveredFilter, tagDiscoveredFilter};

            try {
                ndefDiscoveredFilter.addDataType("*/*");
            } catch (IntentFilter.MalformedMimeTypeException e) {
                throw new RuntimeException("fail", e);
            }
        }
    }

    private void updateConsole(String sender, byte[] data){
        updateConsole(sender, new String(data, Charset.forName("UTF-8")));
    }

    public synchronized void updateConsole(final String sender, final String msg){
        MainActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                consoleText.append(sender + msg);
                scrollBar.smoothScrollTo(0, consoleText.getBottom());
            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();

        final Intent intent = getIntent();
        if(intent != null){
            if(UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(intent.getAction())){
                setupUsbConnection();
            }else if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(getIntent().getAction())) {
                nfcTag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
                updateConsole(SENDER_APP, "NDEF Tag Detected\r\n");
                if(!isTagConfigureMode) {
                    handleNdefTag();
                }
            }else if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(getIntent().getAction())) {
                updateConsole(SENDER_APP, "Non-NDEF Tag Detected\r\n");
                nfcTag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
                if(!isTagConfigureMode){
                    configureTag();
                }
            }
        }

        /* Enable Foreground Dispatcher for NFC events */
        NfcAdapter adapter = NfcAdapter.getDefaultAdapter(this);
        if(adapter != null){
            adapter.enableForegroundDispatch(this,
                    nfcPendingIntent, nfcIntentFiltersArr, null);
        }
    }

    private void handleNdefTag(){
        try {
            final Intent intent = getIntent();
            Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);

            if (rawMsgs != null) {
                NdefMessage[] ndefArray = new NdefMessage[rawMsgs.length];
                for (int i = 0; i < rawMsgs.length; i++) {
                    ndefArray[i] = (NdefMessage) rawMsgs[i];
                    NdefRecord record = ndefArray[0].getRecords()[0];

                    if (record != null) {
                        String mimeType = record.toMimeType();
                        if(mimeType == null || !mimeType.equals("application/vnd.bluetooth.le.oob")){
                            updateConsole(SENDER_APP, "Tag has invalid MIME type\r\n");
                            return;
                        }

                        byte[] payload = record.getPayload();
                        int minLength = BleConnectMessage.ADDRESS_SIZE + BleConnectMessage.SECURITY_KEY_SIZE;
                        if ((payload == null) ||
                                (payload.length < minLength)) {
                            updateConsole(SENDER_APP, "Tag doesn't have necessary information\r\n");
                            return;
                        }

                        BleConnectMessage bleMsg = new BleConnectMessage(record.getPayload());
                        byte[] address = bleMsg.getAddress();
                        byte[] securityKey = bleMsg.getSecurityKey();
                        if (address == null || securityKey == null) {
                            updateConsole(SENDER_APP, "Tag data is not valid\r\n");
                            return;
                        }

                        byte[] tagData = new byte[minLength]; /* 7 bytes address + 16 bytes security key */
                        System.arraycopy(address, 0, tagData, 0, address.length);
                        System.arraycopy(securityKey, 0, tagData, address.length, securityKey.length);
                        sendPacket((byte) 'C', tagData);

                        updateConsole(SENDER_APP,
                                "Connection Initiated, " +
                                        "BLE device name: " + bleMsg.getLocalName() +
                                        ", Address: " + HexDump.toHexString(address) +
                                        ", Security Key: " + HexDump.toHexString(securityKey) +
                                        "\r\n");

                        Log.d(TAG, "BLE device name found from tag is: " + bleMsg.getLocalName() +
                                ", Address read from tag is: " + HexDump.toHexString(address) +
                                ", Security Key is: " + HexDump.toHexString(securityKey));
                    }
                }
            }
        }catch(Exception ex){            
        }
    }

    private void sendPacket(byte command, byte[] payload){

        String data = HexDump.toHexString(payload);

        try {
            if (serialIoManager != null) {
                serialIoManager.writeAsync(new byte[]{command, (byte) (payload.length * 2)});
                serialIoManager.writeAsync(data.getBytes());
                serialIoManager.writeAsync(new byte[]{0x0D});
            }
        }catch(Exception ex) {
            updateConsole(SENDER_APP, "Error " + ex.toString() + "\r\n");
        }

        Log.d(TAG, "Packet Sent: " + command + ", " + data);
    }

    @Override
    protected void onPause() {
        super.onPause();
        NfcAdapter adapter = NfcAdapter.getDefaultAdapter(this);
        if(adapter != null) {
            adapter.disableForegroundDispatch(this);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        closeUsbConnection();
        unregisterReceiver(mUsbReceiver);
    }

    private void setupUsbConnection() {
        if (sPort == null) {
            final Intent intent = getIntent();
            UsbDevice usbDevice = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);

            if (usbDevice != null) {
                if ((usbDevice.getVendorId() == VID) && (usbDevice.getProductId() == PID)) {

                    sPort = new CdcAcmSerialDriver(
                            usbDevice, CTRL_IFACE_NUM, DATA_IFACE_NUM).getPorts().get(0);

                    final UsbManager usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);

                    UsbDeviceConnection connection = usbManager.openDevice(usbDevice);
                    if (connection == null) {
                        Log.e(TAG, "Opening device failed");
                        sPort = null;
                        return;
                    }

                    try {
                        sPort.open(connection);
                        sPort.setParameters(BAUD_RATE, UsbSerialPort.DATABITS_8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
                        serialIoManager = new SerialInputOutputManager(sPort, mListener);
                        mExecutor.submit(serialIoManager);
                        updateConsole(SENDER_APP, "USB device connected.\r\n");
                    } catch (Exception e) {
                        Log.e(TAG, "Error setting up device: " + e.getMessage(), e);
                        try {
                            sPort.close();
                        } catch (Exception e2) {
                        }
                        sPort = null;
                        return;
                    }
                }
                     /* User permission is handled through Android system while launching the
                       activity. This activity is automatically launched since USB_ATTACHED
                       action is set as intent filter in the manifest file. Also, this activity
                       is defined as SingleTask in the manifest. Therefore, if the USB is plugged
                       in once again, a new activity will not be launched instead the onNewIntent()
                       of the existing activity will be called.
                       Also note that until the user sets this app as default app to be opened
                       when this USB is plugged, the message asking for user permission will always
                       pop-up whenever USB is plugged in.
                     */
            }
        }
    }

    private void closeUsbConnection(){
        if (serialIoManager != null) {
            Log.i(TAG, "Stopping io manager ..");
            serialIoManager.stop();
            serialIoManager = null;
        }

        if (sPort != null) {
            try {
                sPort.close();
            } catch (IOException e) {
            }
            sPort = null;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case R.id.action_clear:
                consoleText.setText("");
                break;
            case R.id.action_writeTag:
                configureTag();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void configureTag(){
        final String allowedChars = "0123456789ABCDEF";
        View view = View.inflate(this, R.layout.configure_tag, null);
        final EditText deviceNameText = (EditText)view.findViewById(R.id.deviceNameText);
        final EditText addrText = (EditText)view.findViewById(R.id.deviceAddrText);
        final EditText keyText = (EditText)view.findViewById(R.id.securityKeyText);
        final TextView hintText = (TextView)view.findViewById(R.id.hintText);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Configure Tag");
        builder.setView(view);

        builder.setPositiveButton("Configure Tag", null);

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                isTagConfigureMode = false;
                dialog.cancel();
            }
        });

        final AlertDialog dialog = builder.create();
        isTagConfigureMode = true;
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(nfcTag == null){
                    hintText.setText("Tag Not Found");
                    return;
                }

                String name = deviceNameText.getText().toString();
                String addr = addrText.getText().toString();
                String key = keyText.getText().toString();

                if(addr == null || key == null || name == null){
                    return;
                }

                if(name.equals("") || addr.equals("") || key.equals("")){
                    hintText.setText("Enter something or Hit Cancel");
                    return;
                }

               if(addr.length() != 12){
                    hintText.setText("Address should have 12 characters");
                    return;
                }

                addr = addr.toUpperCase();
                for(int i = 0; i < addr.length(); i++){
                    if(!allowedChars.contains(String.valueOf(addr.charAt(i)))){
                        hintText.setText("Only Hex characters are allowed");
                        return;
                    }
                }

                if(key.length() != BleConnectMessage.SECURITY_KEY_SIZE){
                    hintText.setText("Enter 16 characters for Security Key");
                    return;
                }

                Ndef ndef = Ndef.get(nfcTag);
                try {
                    ndef.connect();
                    ndef.writeNdefMessage(getNdefRecrod(addr, key, name));
                    ndef.close();
                }catch(Exception ioe) {
                    hintText.setText("Error in writing to Tag. Ensure Tag is in the proximity");
                    nfcTag = null;
                    return;
                }

                updateConsole(SENDER_APP, "Tag Configured Successfully!\r\n");
                isTagConfigureMode = false;
                dialog.dismiss();
            }
        });
   }

    private NdefMessage getNdefRecrod(String addr, String key, String name){
        int i;
        byte[] payload = new byte[27 + 2 + name.length()]; //7 byte address + 16 bytes key
        byte[] addrArray = HexDump.hexStringToByteArray(addr);

        /* Store address */
        payload[0] = BleConnectMessage.ADDRESS_SIZE + 1; //address length
        payload[1] = BleConnectMessage.ADDRESS_DATA_TYPE;
        for(i = 0; i < addrArray.length; i++){
            payload[2 + i] = addrArray[addrArray.length - 1 - i];
        }
        payload[8] = 0x00; //Address Type = Public

        /* Store security key */
        payload[9] = BleConnectMessage.SECURITY_KEY_SIZE + 1;
        payload[10] = BleConnectMessage.SECURITY_KEY_DATA_TYPE;
        System.arraycopy(key.getBytes(), 0, payload, 11, BleConnectMessage.SECURITY_KEY_SIZE);

        payload[27] = (byte)(name.length() + 1);
        payload[28] = BleConnectMessage.LOCAL_NAME_DATA_TYPE;
        System.arraycopy(name.getBytes(), 0, payload, 29, name.length());

        NdefRecord mimeRecord = new NdefRecord(NdefRecord.TNF_MIME_MEDIA,
                "application/vnd.bluetooth.le.oob".getBytes(Charset.forName("US-ASCII")),
                new byte[0], payload);

        return new NdefMessage(mimeRecord);
    }
}
